public class Entry {
    public static void main(String[] args) {
        Action action = new Action();
        action.getGui().setVisible(true);
    }
}